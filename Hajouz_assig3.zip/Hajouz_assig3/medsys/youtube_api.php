<?php

function youtube_search ($apiKey, $maxResults, $searchQuery) {
    return json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/search?q='.$searchQuery.'&key='.$apiKey.'&part=snippet&&maxResults='.$maxResults), true);
}



//new: AIzaSyB9-RVumKHbEp4UtH8vC3Pvq-vXZuE--Zs
//old: AIzaSyB4_pC_kJ5_v2FhetWSv1y-ZzhmIfC6sEw