<?php

class Test_Session {
    
    // Properties
    public $test_SessionID;
    public $name;
    
    private $table_name = 'Test_Session';
    
    // Methods
    
    public function find ($value) {
        $obj = new Test_Session;
        if ($value != null) {
            include ('config/connect_to_db.php');
            $sql_query = $conn->query("select * from ".$obj->table_name." where test_SessionID='" . $value. "'");
            if ($sql_query->num_rows > 0) {
                $row_obj = $sql_query->fetch_assoc();
                $obj->test_SessionID = $row['test_SessionID'];
                $obj->type = $row['type'];
                $obj->test = $row['test'];
                $obj->DataURL = $row['DataURL'];
            }
        }
        return $obj;
    }
    
    public function all () {
        $obj = new Test_Session;
        include ('config/connect_to_db.php');
        $sql_query = $conn->query("select * from ".$obj->table_name);
        $all_rows = [];
        while ($row = $sql_query->fetch_assoc()) {
            $row_obj = new Test_Session;
            $row_obj->test_SessionID = $row['test_SessionID'];
            $row_obj->type = $row['type'];
            $row_obj->test = $row['test'];
            $row_obj->DataURL = $row['DataURL'];
            $all_rows[] = $row_obj;
        }
        return $all_rows;
    }
    
    public function save () {
        include ('config/connect_to_db.php');
        if (empty($this->test_SessionID)) {
            $sql_query = $conn->query("insert into ".$this->table_name." (type , test , DataURL) values ('".$this->type."', '".$this->test."', '".$this->DataURL."')");
            $this->test_SessionID = $conn->insert_id;
        } else {
            $sql_query = $conn->query("update ".$this->table_name." set type='".$this->type."', test='".$this->test."', DataURL='".$this->DataURL."' where test_SessionID='".$this->test_SessionID."'");
        }
    }
    
}


?>