<?php

class Role {
    
    // Properties
    public $roleID;
    public $name;
    
    private $table_name = 'Role';
    
    // Methods
    
    public function find ($value) {
        $obj = new Role;
        if ($value != null) {
            include ('config/connect_to_db.php');
            $sql_query = $conn->query("select * from ".$obj->table_name." where roleID='" . $value. "'");
            if ($sql_query->num_rows > 0) {
                $row = $sql_query->fetch_assoc();
                $obj->roleID = $row['roleID'];
                $obj->name = $row['name'];
                $obj->type = $row['type'];
            }
        }
        return $obj;
    }
    
    public function all () {
        $obj = new Role;
        include ('config/connect_to_db.php');
        $sql_query = $conn->query("select * from ".$obj->table_name);
        $all_rows = [];
        while ($row = $sql_query->fetch_assoc()) {
            $row_obj = new Role;
            $row_obj->roleID = $row['roleID'];
            $row_obj->name = $row['name'];
            $row_obj->type = $row['type'];
            $all_rows[] = $row_obj;
        }
        return $all_rows;
    }
    
    public function save () {
        include ('config/connect_to_db.php');
        if (empty($this->roleID)) {
            $sql_query = $conn->query("insert into ".$this->table_name." (name , type) values ('".$this->name."', '".$this->type."')");
            $this->roleID = $conn->insert_id;
        } else {
            $sql_query = $conn->query("update ".$this->table_name." set name='".$this->name."', type='".$this->type."' where roleID='".$this->roleID."'");
        }
    }
    
}


?>