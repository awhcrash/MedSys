<?php

class Test {
    
    // Properties
    public $testID;
    public $name;
    
    private $table_name = 'Test';
    
    // Methods
    
    public function find ($value) {
        $obj = new Test;
        if ($value != null) {
            include ('config/connect_to_db.php');
            $sql_query = $conn->query("select * from ".$obj->table_name." where testID='" . $value. "'");
            if ($sql_query->num_rows > 0) {
                $row = $sql_query->fetch_assoc();
                $obj->testID = $row['testID'];
                $obj->dateTime = $row['dateTime'];
                $obj->therapy = $row['therapy'];
            }
        }
        return $obj;
    }
    
    public function all () {
        $obj = new Test;
        include ('config/connect_to_db.php');
        $sql_query = $conn->query("select * from ".$obj->table_name);
        $all_rows = [];
        while ($row = $sql_query->fetch_assoc()) {
            $row_obj = new Test;
            $row_obj->testID = $row['testID'];
            $row_obj->dateTime = $row['dateTime'];
            $row_obj->therapy = $row['therapy'];
            $all_rows[] = $row_obj;
        }
        return $all_rows;
    }
    
    public function save () {
        include ('config/connect_to_db.php');
        if (empty($this->testID)) {
            $sql_query = $conn->query("insert into ".$this->table_name." (dateTime , therapy) values ('".$this->dateTime."' , '".$this->therapy."')");
            $this->testID = $conn->insert_id;
        } else {
            $sql_query = $conn->query("update ".$this->table_name." set dateTime='".$this->dateTime."' , set therapy='".$this->therapy."' where testID='".$this->testID."'");
        }
    }
    
}


?>