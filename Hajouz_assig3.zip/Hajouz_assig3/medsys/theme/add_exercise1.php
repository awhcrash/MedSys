<!--<div id="observablehq-c646a259"></div>
<script type="module">
import {Runtime, Inspector} from "https://cdn.jsdelivr.net/npm/@observablehq/runtime@4/dist/runtime.js";
import define from "https://api.observablehq.com/@mbostock/draw-your-own-connected-scatterplot.js?v=3";
const inspect = Inspector.into("#observablehq-c646a259");
(new Runtime).module(define, name => (name === "viewof data") && inspect());
</script>-->






    
    <script src='https://cdn.plot.ly/plotly-latest.min.js'>    </script>
        
    	<div id='myDiv'><!-- Plotly chart will be drawn inside this DIV -->
         
          <script>
            var x = Array.from({length: 500}, () => Math.random()*(6-3)+3);
            var y = Array.from({length: 500}, () => Math.random()*(6-3)+3);

            var data = [{
              x: x,
              y: y,
              type: 'scatter',
              mode: 'markers',
              marker: {
                color: 'rgb(17, 157, 255)',
                size: 20,
                line: {
                  color: 'rgb(231, 99, 250)',
                  width: 2
                }
              },
              showlegend: false
              }, {
              x: [2],
              y: [4.5],
              type: 'scatter',
              mode: 'markers',
              marker: {
                color: 'rgb(17, 157, 255)',
                size: 60,
                line: {
                  color: 'rgb(231, 99, 250)',
                  width: 6
                }
              },
              showlegend: false
            }]

            Plotly.newPlot('myDiv', data)
              
               </script>
            
               
          </div>

        
              
         
        


     


