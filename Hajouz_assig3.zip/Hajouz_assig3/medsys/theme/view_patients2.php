<?php 

$patients_list = User::all('where role=3');

?>

<style>
       
       th,h1,td,h4,h3 {
  color: white;
       }
    
    </style>


<div class="container">
    
    <table class="table" color="white">

        <thead>
            <tr>
                <th scope="col" color="white">userID</th>
                <th scope="col">Username</th>
                <th scope="col">Email</th>
                <th scope="col">Number of Total Exe.</th>
                <!--<th scope="col">Location</th>-->
            </tr>
        </thead>

        <tbody>
            <?php foreach ($patients_list as $p) : ?>
            <tr>
                <th scope="row"><?php print $p->userID; ?></th>
                <td><?php print $p->username; ?></td>
                <td><?php print $p->email; ?></td>
                <td><?php print $p->e0 + $p->e1 + $p->e2 + $p->e3 + $p->e5; ?></td>
               
            </tr>
            <?php endforeach; ?>
        </tbody>

    </table>
</div>