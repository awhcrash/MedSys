<nav class="navbar navbar-expand-md navbar-dark bg-dark mb-4">
        <a class="navbar-brand" href="#"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    
    <a class="navbar-brand" href="#"><i class="fa fa-tachometer mr-3"></i></a>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.php" role="tab"><i class="fa fa-home"></i>&nbsp; Home</a>
            </li>
            
            <?php if ($auth->role == 3) : ?>
            <li class="nav-item" >
                <a class="nav-link" href="index.php?action=view_videos" role="tab"><i class="fa fa-youtube-play"></i>&nbsp; Recommended Videos</a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="index.php?action=add_exercise" role="tab"><i class="fa fa-paint-brush"></i>&nbsp; Draw Something </a>
            </li>
            
            
            
          <li class="nav-item">
                <a class="nav-link" href="index.php?action=add_exercise1" role="tab"><i class="fa fa-circle-thin"></i>&nbsp; 1st Exercise</a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="index.php?action=add_exercise2" role="tab"><i class="fa fa-cube"></i>&nbsp; 2nd Exercise</a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="index.php?action=add_exercise3" role="tab"><i class="fa fa-adjust"></i>&nbsp; 3rd Exercise</a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="index.php?action=add_exercise5" role="tab"><i class="fa fa-globe"></i>&nbsp; Discover The Earth</a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="index.php?action=my_activities" role="tab"><i class="a fa-id-card-o"></i>&nbsp; Your Activities</a>
            </li>
            
           
            
            
           
            
            <li class="nav-item">
                <a class="nav-link" href="index.php?action=account_settings" role="tab"><i class="fa fa-cog"></i>&nbsp; My Account</a>
            </li>
            <?php endif; ?>
            
            <?php if ($auth->role == 1 ) : ?>
            <li class="nav-item">
                <a class="nav-link" href="index.php?action=view_patients2" role="tab"><i class="fa fa-list"></i>&nbsp; Patients List</a>
            </li>
            <?php endif; ?>
            
            <?php if ($auth->role == 2) : ?>
            
            <li class="nav-item">
                <a class="nav-link" href="index.php?action=view_patients" role="tab"><i class="fa fa-list"></i>&nbsp; Patients List</a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="index.php?action=latest_news" role="tab"><i class="fa fa-newspaper-o"></i>&nbsp; Latest News</a>
            </li>
            
            <?php endif; ?>
            
        </ul>
        
        <ul class="navbar-nav navbar-right">
            <li class="nav-item active">
                <a class="nav-link"><i class="fa fa-handshake-o"></i>&nbsp; Welcome <?php print $auth->username; ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" style="cursor:pointer;" href="index.php?type=logout"><i class="fa fa-power-off"></i>&nbsp; Logout</a>
            </li>
        </ul>
        
    </div>
</nav>

