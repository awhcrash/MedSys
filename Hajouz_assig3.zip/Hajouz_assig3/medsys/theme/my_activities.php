<?php 


//$p = User::find($google_user_email);

?>

<style>
       
       th,h1,td,h4,h3 {
  color: white;
       }
    
    </style>


<div class="container">
    <h3>Here you can find the number of your activities about every exercise!</h3>
    <table class="table" color="white">

        <thead>
            <tr>
                <th scope="col" >Drawing Exercise</th>
                <th scope="col">First Exercise</th>
                <th scope="col">Second Exercise</th>
                <th scope="col">Third Exercise</th>
                <th scope="col">Discovering Exercise</th>
                <!--<th scope="col">Location</th>-->
            </tr>
        </thead>

        <tbody>
            
            <tr>
                <th scope="row"><?php print $auth->e0; ?></th>
                <td><?php print $auth->e1; ?></td>
                <td><?php print $auth->e2; ?></td>
                <td><?php print $auth->e3; ?></td>
                <td><?php print $auth->e5; ?></td>
               
            </tr>
            
        </tbody>

    </table>
</div>