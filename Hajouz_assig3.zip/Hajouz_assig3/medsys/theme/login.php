<style>
       
       h2 {
  color: white;
       }
    
    label   {
  color: white;
       }
  
    </style>



<div class="container">
    <center>
        
        <br>
        
        <form class="login-form" method="post" action=".?type=login">
            
            <h2>Login to your account</h2>
            
            <hr>
            <br>
            
            <div class="form-group">
                <label for="user-email" color="white">Email</label>
                <input type="text" class="form-control" id="user-email" name="email" placeholder="Your Email ...">
            </div>
            
            <div class="form-group">
                <label for="user-password">Password</label>
                <input type="password" class="form-control" id="user-password" name="password" placeholder="Your Password ...">
            </div>
            
            <button type="submit" class="btn btn-primary">Login</button>
            
            <br>
            
            <?php if (isset($user_login_error)) : ?>
            <div class="alert alert-danger" role="alert">
                <?php print $user_login_error; ?>
            </div>
            <?php endif; ?>
            
            <hr>
            
            <h4>Or Login Via Facebook or Google</h4>
            
            <br>
            
            <fb:login-button scope="public_profile,email" onlogin="checkFBLoginState();"></fb:login-button>
            <br>
            <button type="button" class="btn btn-primary btn-md mt-2" onclick="GoogleAuthInit();">Via Google</button>
            <br>
            <a type="button" class="btn btn-primary btn-md mt-2" href="./twapp">Via Twitter</a>

        </form>
    </center>

</div>