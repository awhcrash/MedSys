<!DOCTYPE html>
<html lang="en">
    
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v4.0.1">
    <title>Latest News</title>
    
    <link href="https://fonts.googleapis.com/css?family=Bree+Serif" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/navbar-static/">

    <!-- Bootstrap core CSS -->
    <link href="assets/dist/css/bootstrap.css" rel="stylesheet">
    
    <!-- Custom styles for this template -->
    <link href="navbar-top.css" rel="stylesheet">
    
    <link rel="stylesheet" href="css/main.css">
    
    

   <style>
       
       h1 {
  color: white;
       }
        h4 {
  color: white;
       }
        h3 {
  color: white;
       }

       
        body,html{
           width: 100%;
           height: 0px;
       }
body {
  margin: 0;
  background: #222;
  min-width: 960px;
}

rect {
  fill: none;
  pointer-events: all;
}

circle {
  fill: none;
  stroke-width: 2.5px;
}
       
       #logo {
           position: absolute;
           top: 50%;
           left: 50%;
           transform: translate(-50%,-50%);
       }
     
       #logo path:nth-child(1){
           stroke-dasharray: 577;
           stroke-dasharray: 666px;
           animation: line-anim 2s ease forwards;
       }
        #logo path:nth-child(2){
            stroke-dasharray: 200px;
           stroke-dasharray: 50px;
           
       } #logo path:nth-child(3){
           stroke-dasharray: 200px;
           stroke-dasharray: 50px;
           
       } #logo path:nth-child(4){
           stroke-dasharray: 200px;
           stroke-dasharray: 50px;
           
       } #logo path:nth-child(5){
           stroke-dasharray: 200px;
           stroke-dasharray: 50px;
           
       } #logo path:nth-child(6){
           stroke-dasharray: 200px;
           stroke-dasharray: 50px;
           
       }
       
       
       @keyframes line-anim{
           to{
               strok-dashoffset: 0;
           }
           
       }
       
       

</style>
    
    <script src="https://unpkg.com/konva@4.0.16/konva.min.js"></script>
       <script src="//d3js.org/d3.v3.min.js"></script>

    
    
    
</head>


<?php

$object = simplexml_load_file("https://www.news-medical.net/tag/feed/Parkinsons-Disease.aspx");
    
    
   




    echo '<ul>';

    
     foreach($object->channel->item as $item)
        {
            $title = $item->title;
            echo "<a href='".$item->link."' target='_blank'><h3>".$item->title."<h3></a>
                    <h4 style='color:#398e8e'>".$item->description."<h4>
                            <br>";

             }
    
    echo '</ul>';
    
    ?>
    
    




</html>

    