

<script>
    
    function logout () {
        FB.logout();
    }
    
    var auth2;
    
    function GoogleAuthInit () {
        gapi.load('auth2', function() {
            auth2 = gapi.auth2.init({
                client_id: '247217940622-to6p6r2keo789r99cj31p5sfq0gp3bp6.apps.googleusercontent.com',
                fetch_basic_profile: true,
                scope: 'profile'
            });

            // Sign the user in, and then retrieve their ID.
            auth2.signIn().then(function() {
                var profile = auth2.currentUser.get().getBasicProfile();
                window.location.href = 'index.php?type=google_login&email=' + profile.getEmail() + '&name=' + profile.getName();
            });
        });
    }
    
    
    
    //var GoogleAuth;
    //alert(GoogleAuth.getBasicProfile().getEmail());
    
    function checkFBLoginState () {
        FB.getLoginStatus(function(response) {
            window.location.href = 'index.php?type=fb_login&access_token=' + response.authResponse.accessToken;
        });
    }
    
    function onGoogleSignIn (googleUser) {
        //var profile = googleUser.getBasicProfile();
        //window.location.href = 'index.php?type=google_login&email=' + profile.getEmail() + '&name=' + profile.getName();
        alert(googleUser.getBasicProfile().getEmail());
    }
    
</script>


<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script>
    window.jQuery || document.write('<script src="assets/js/vendor/jquery.slim.min.js"><\/script>')

</script>
<script src="assets/dist/js/bootstrap.bundle.js"></script>



</body>

</html>