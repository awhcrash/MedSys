<?php

session_start();
require 'autoload.php';
use Abraham\TwitterOAuth\TwitterOAuth;

//$request_token = ['oauth_token' => 'i5qnjQAAAAABBgy4AAABcyPZfhg', 'oauth_token_secret' => 'sadsaddsasadsad'];

define('CONSUMER_KEY', 'N3x4e4ZNqhcqUVBE7Z0m8BC0x'); // add your app consumer key between single quotes
define('CONSUMER_SECRET', 'HEifopUdTltC4KL12r8RMLiZR95GiC2m7YM82nidu3sS87qzud'); // add your app consumer secret key between single quotes
define('OAUTH_CALLBACK', 'https://awhcrash.com/medsys/twapp/callback.php'); // your app callback URL

if (!isset($_SESSION['twitter_access_token'])) {
	$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET);
	$request_token = $connection->oauth('oauth/request_token', array('oauth_callback' => OAUTH_CALLBACK));
	$_SESSION['oauth_token'] = $request_token['oauth_token']; // S1
	$_SESSION['oauth_token_secret'] = $request_token['oauth_token_secret']; // S2
	$url = $connection->url('oauth/authorize', ['oauth_token' => $request_token['oauth_token']]);
    //print $url;
	header('Location:' . $url);
} else {
	$access_token = $_SESSION['twitter_access_token'];
	$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);
	$user = $connection->get("account/verify_credentials");
    header('Location: https://awhcrash.com/medsys/index.php?type=twitter_login&screen_name=' . $user->screen_name . '&name=' . $user->name);
    //print '<pre>';
    //print_r ($user);
	//print '</pre>';
}