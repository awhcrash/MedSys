<?php 

$auth_role = Role::find($auth->role);

$page = 'home.php';





if (isset($_GET['action'])) {
    
    $action = $_GET['action'];
    
    //Patients
    if ($auth->role == 3) {
        if ($action == 'view_videos') {
            $page = 'youtube_videos.php';
        } else if ($action == 'account_settings') {
            $page = 'patient_account.php';
        } else if ($action == 'save_location') {
            
            if (isset($_GET['latlng'])) {
                $auth->latlng = $_GET['latlng'];
                $auth->save();
            }
            
            header('Location: index.php?action=account_settings');
            exit();
        }  else if ($action == 'add_exercise') {
            $page = 'add_exercise.php';
            $auth->e0 = $auth->e0 + 1;
            $auth->save();
        }
        else if ($action == 'add_exercise1') {
            $page = 'add_exercise1.php';
            $auth->e1 = $auth->e1 + 1;
            $auth->save();
        }
        else if ($action == 'add_exercise2') {
            $page = 'add_exercise2.php';
            $auth->e2 = $auth->e2 + 1;
            $auth->save();
        }
        else if ($action == 'add_exercise3') {
            $page = 'add_exercise3.php';
            $auth->e3 = $auth->e3 + 1;
            $auth->save();
        }
        else if ($action == 'add_exercise5') {
            $page = 'add_exercise5.php';
            $auth->e5 = $auth->e5 + 1;
            $auth->save();
        }
        else if ($action == 'my_activities') {
            $page = 'my_activities.php';
            
        }
        //Doctor
    } else if ($auth->role == 1 ) {
        if ($action == 'view_patients2') {
            $page = 'view_patients2.php';
        }
    } //Researcher
    else if ($auth->role == 2) {
        if ($action == 'view_patients') {
            $page = 'view_patients.php';
        }
        else if ($action == 'latest_news') {
            $page = 'latest_news.php';
        }
    } 
}

include ('theme/header.php');
include('theme/navbar.php');
include('theme/'.$page);
include ('theme/footer.php');

//$auth->role == 1 || 

?>