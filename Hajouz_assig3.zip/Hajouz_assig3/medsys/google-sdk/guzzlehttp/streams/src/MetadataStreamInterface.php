<?php
namespace GuzzleHttp\Stream;

/**
 * This interface is deprecated and should no longer be used. Just use
 * StreamInterface now that the getMetadata method has been added to
 * StreamInterface.
 *
 * @deprecated
 */
interface MetadataStreamInterface extends StreamInterface {}
