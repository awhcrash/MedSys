<?php

/*include ('classes/user.php');

$auth = new User;

$auth->username = 'aaaa';
$auth->email = 'adssdasadsad@msad.com';
$auth->password = rand(10000,99999);
$auth->role = rand(1,2);
$auth->organization = 0;
$auth->latlng = 0;
$auth->e0 = 0;
$auth->save();

print_r($auth);*/

?>