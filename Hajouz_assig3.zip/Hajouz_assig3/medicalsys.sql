-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Värd: localhost
-- Tid vid skapande: 23 okt 2020 kl 07:53
-- Serverversion: 10.4.11-MariaDB
-- PHP-version: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databas: `medicalsys`
--

-- --------------------------------------------------------

--
-- Tabellstruktur `Medicine`
--

CREATE TABLE `Medicine` (
  `medicineID` int(11) NOT NULL,
  `name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `Medicine`
--

INSERT INTO `Medicine` (`medicineID`, `name`) VALUES
(1, 'Panadol'),
(2, 'Sitamol'),
(3, 'aaaaaa');

-- --------------------------------------------------------

--
-- Tabellstruktur `Note`
--

CREATE TABLE `Note` (
  `noteID` int(11) NOT NULL,
  `test_session` int(11) NOT NULL,
  `note` longtext NOT NULL,
  `med` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `Note`
--

INSERT INTO `Note` (`noteID`, `test_session`, `note`, `med`) VALUES
(1, 1, 'this patient has strong headache and that was clear from his reactions', 2);

-- --------------------------------------------------------

--
-- Tabellstruktur `Organization`
--

CREATE TABLE `Organization` (
  `organizationID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellstruktur `Role`
--

CREATE TABLE `Role` (
  `roleID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `Role`
--

INSERT INTO `Role` (`roleID`, `name`, `type`) VALUES
(1, 'Physician', 'physician'),
(2, 'Researcher', 'researcher'),
(3, 'Patient', 'patient');

-- --------------------------------------------------------

--
-- Tabellstruktur `Test`
--

CREATE TABLE `Test` (
  `testID` int(11) NOT NULL,
  `dateTime` datetime NOT NULL,
  `therapy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `Test`
--

INSERT INTO `Test` (`testID`, `dateTime`, `therapy`) VALUES
(1, '2019-10-08 00:00:00', 1);

-- --------------------------------------------------------

--
-- Tabellstruktur `Test_Session`
--

CREATE TABLE `Test_Session` (
  `test_SessionID` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `test` int(11) NOT NULL,
  `DataURL` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `Test_Session`
--

INSERT INTO `Test_Session` (`test_SessionID`, `type`, `test`, `DataURL`) VALUES
(1, 1, 1, '');

-- --------------------------------------------------------

--
-- Tabellstruktur `Therapy`
--

CREATE TABLE `Therapy` (
  `therapyID` int(11) NOT NULL,
  `patient` int(11) NOT NULL,
  `med` int(11) NOT NULL,
  `therapylist` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `Therapy`
--

INSERT INTO `Therapy` (`therapyID`, `patient`, `med`, `therapylist`) VALUES
(1, 4, 2, 1);

-- --------------------------------------------------------

--
-- Tabellstruktur `Therapy_List`
--

CREATE TABLE `Therapy_List` (
  `therapy_listID` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `medicine` int(11) NOT NULL,
  `Dosage` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `Therapy_List`
--

INSERT INTO `Therapy_List` (`therapy_listID`, `name`, `medicine`, `Dosage`) VALUES
(1, 'Headache', 1, '3 drugs per day');

-- --------------------------------------------------------

--
-- Tabellstruktur `User`
--

CREATE TABLE `User` (
  `userID` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `organization` int(11) DEFAULT NULL,
  `role` int(11) NOT NULL,
  `latlng` varchar(100) DEFAULT '',
  `e0` int(11) NOT NULL,
  `e1` int(11) NOT NULL,
  `e2` int(11) NOT NULL,
  `e3` int(11) NOT NULL,
  `e5` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumpning av Data i tabell `User`
--

INSERT INTO `User` (`userID`, `username`, `email`, `password`, `organization`, `role`, `latlng`, `e0`, `e1`, `e2`, `e3`, `e5`) VALUES
(4, 'Batman', 'physician@gm.c', '111', 0, 1, '', 24, 0, 0, 0, 0),
(21, 'Hercules', 'researcher@gm.c', '222', 0, 2, '', 0, 0, 0, 0, 0),
(22, 'Xena', 'patient@gm.c', '333', 0, 3, '60.128161000000006,18.643501', 14, 8, 4, 6, 9),
(23, 'Alisa Sotsenko', 'alisasotsenko@gmail.com', '40333', 0, 3, '', 0, 0, 0, 0, 0),
(33, 'AWH', 'a@a.a', 'aaa', 0, 3, '', 1, 0, 0, 0, 0);

--
-- Index för dumpade tabeller
--

--
-- Index för tabell `Medicine`
--
ALTER TABLE `Medicine`
  ADD PRIMARY KEY (`medicineID`);

--
-- Index för tabell `Note`
--
ALTER TABLE `Note`
  ADD PRIMARY KEY (`noteID`);

--
-- Index för tabell `Organization`
--
ALTER TABLE `Organization`
  ADD PRIMARY KEY (`organizationID`);

--
-- Index för tabell `Role`
--
ALTER TABLE `Role`
  ADD PRIMARY KEY (`roleID`);

--
-- Index för tabell `Test`
--
ALTER TABLE `Test`
  ADD PRIMARY KEY (`testID`);

--
-- Index för tabell `Test_Session`
--
ALTER TABLE `Test_Session`
  ADD PRIMARY KEY (`test_SessionID`);

--
-- Index för tabell `Therapy`
--
ALTER TABLE `Therapy`
  ADD PRIMARY KEY (`therapyID`);

--
-- Index för tabell `Therapy_List`
--
ALTER TABLE `Therapy_List`
  ADD PRIMARY KEY (`therapy_listID`);

--
-- Index för tabell `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT för dumpade tabeller
--

--
-- AUTO_INCREMENT för tabell `Medicine`
--
ALTER TABLE `Medicine`
  MODIFY `medicineID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT för tabell `Note`
--
ALTER TABLE `Note`
  MODIFY `noteID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT för tabell `Organization`
--
ALTER TABLE `Organization`
  MODIFY `organizationID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT för tabell `Role`
--
ALTER TABLE `Role`
  MODIFY `roleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT för tabell `Test`
--
ALTER TABLE `Test`
  MODIFY `testID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT för tabell `Test_Session`
--
ALTER TABLE `Test_Session`
  MODIFY `test_SessionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT för tabell `Therapy`
--
ALTER TABLE `Therapy`
  MODIFY `therapyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT för tabell `Therapy_List`
--
ALTER TABLE `Therapy_List`
  MODIFY `therapy_listID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT för tabell `User`
--
ALTER TABLE `User`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
